# Microservicio Logística y Transporte

Proyecto minimal listo para ejecutar localmente y subir a GitHub.

## Contenido
- Spring Boot (Java 17)
- PostgreSQL (docker-compose)
- Entidades: AgenteAliado, Vehiculo, Conductor, ClienteFinal
- Endpoints REST básicos

## Ejecutar localmente (con Docker)
1. Compilar: `mvn clean package -DskipTests`
2. Levantar: `docker-compose up --build`
3. Acceder: `http://localhost:8080`

## Endpoints (ejemplos)
- POST /api/conductores
- GET  /api/conductores/disp
- PUT  /api/conductores/{id}/vehiculo/{idVehiculo}
- POST /api/vehiculos
- PUT  /api/vehiculos/{id}/conductor/{idConductor}
- POST /api/agentes
- PUT  /api/agentes/{id}/almacen/{idAlmacen}
- POST /api/clientes

