package com.example.logistica.service.impl;

import com.example.logistica.entity.Vehiculo;
import com.example.logistica.repository.ConductorRepository;
import com.example.logistica.repository.VehiculoRepository;
import com.example.logistica.service.VehiculoService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VehiculoServiceImpl implements VehiculoService {
    private final VehiculoRepository vehiculoRepository;
    private final ConductorRepository conductorRepository;

    @Override
    public Vehiculo registrar(Vehiculo v) {
        return vehiculoRepository.save(v);
    }

    @Override
    @Transactional
    public void asignarConductor(Long vehiculoId, Long conductorId) {
        Vehiculo v = vehiculoRepository.findById(vehiculoId).orElseThrow(() -> new RuntimeException("Vehiculo no encontrado"));
        v.setIdConductor(conductorId);
        vehiculoRepository.save(v);
        // conductor updated in conductor service or DB triggers; keep simple
    }
}
