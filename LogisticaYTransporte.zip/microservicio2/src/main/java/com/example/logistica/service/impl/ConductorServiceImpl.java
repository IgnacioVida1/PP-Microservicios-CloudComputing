package com.example.logistica.service.impl;

import com.example.logistica.dto.ConductorDTO;
import com.example.logistica.entity.Conductor;
import com.example.logistica.entity.Vehiculo;
import com.example.logistica.repository.ConductorRepository;
import com.example.logistica.repository.VehiculoRepository;
import com.example.logistica.service.ConductorService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ConductorServiceImpl implements ConductorService {

    private final ConductorRepository conductorRepository;
    private final VehiculoRepository vehiculoRepository;

    @Override
    public ConductorDTO registrar(ConductorDTO dto) {
        Conductor c = new Conductor();
        c.setNombre(dto.getNombre());
        c.setDni(dto.getDni());
        c.setTelefono(dto.getTelefono());
        c.setDisponible(true);
        c = conductorRepository.save(c);
        dto.setIdConductor(c.getIdConductor());
        dto.setDisponible(c.getDisponible());
        return dto;
    }

    @Override
    @Transactional
    public void asignarVehiculo(Long conductorId, Long vehiculoId) {
        Conductor c = conductorRepository.findById(conductorId)
                .orElseThrow(() -> new RuntimeException("Conductor no encontrado"));
        if (!c.getDisponible()) throw new RuntimeException("Conductor no disponible");
        Vehiculo v = vehiculoRepository.findById(vehiculoId)
                .orElseThrow(() -> new RuntimeException("Vehiculo no encontrado"));
        // assign
        c.setIdVehiculo(vehiculoId);
        c.setDisponible(false);
        conductorRepository.save(c);
        v.setIdConductor(conductorId);
        vehiculoRepository.save(v);
    }

    @Override
    public List<ConductorDTO> consultarDisponibilidad() {
        return conductorRepository.findByDisponibleTrue()
                .stream()
                .map(c -> {
                    ConductorDTO dto = new ConductorDTO();
                    dto.setIdConductor(c.getIdConductor());
                    dto.setNombre(c.getNombre());
                    dto.setDni(c.getDni());
                    dto.setTelefono(c.getTelefono());
                    dto.setDisponible(c.getDisponible());
                    return dto;
                }).collect(Collectors.toList());
    }
}
