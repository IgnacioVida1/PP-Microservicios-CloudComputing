package com.example.logistica.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "cliente_final")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteFinal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idClienteFinal;
    private String nombre;
    private String correo;
    private String telefono;
    private String direccionPrincipal;
}
