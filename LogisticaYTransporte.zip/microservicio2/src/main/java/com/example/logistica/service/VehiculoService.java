package com.example.logistica.service;

import com.example.logistica.entity.Vehiculo;

public interface VehiculoService {
    Vehiculo registrar(Vehiculo v);
    void asignarConductor(Long vehiculoId, Long conductorId);
}
