package com.example.logistica.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "vehiculo")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Vehiculo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idVehiculo;

    private Long idConductor;
    private String nombre;
    private String tipo;
    private String modelo;
    private String color;
    @Column(unique = true)
    private String placa;
}
