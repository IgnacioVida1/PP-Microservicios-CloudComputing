package com.example.logistica.repository;

import com.example.logistica.entity.AgenteAliado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AgenteRepository extends JpaRepository<AgenteAliado, Long> {}
