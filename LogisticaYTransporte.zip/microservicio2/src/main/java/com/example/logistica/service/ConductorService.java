package com.example.logistica.service;

import com.example.logistica.dto.ConductorDTO;

import java.util.List;

public interface ConductorService {
    ConductorDTO registrar(ConductorDTO dto);
    void asignarVehiculo(Long conductorId, Long vehiculoId);
    List<ConductorDTO> consultarDisponibilidad();
}
