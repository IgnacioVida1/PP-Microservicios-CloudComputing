package com.example.logistica.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "agente_aliado")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgenteAliado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idAgente;

    private Long idAlmacen;

    // simplified: store as comma-separated string for portability
    private String idsConductor;

    private String nombre;
    private String ruc;
    private String telefono;
}
