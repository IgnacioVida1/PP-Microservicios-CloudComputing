package com.example.logistica.controller;

import com.example.logistica.entity.AgenteAliado;
import com.example.logistica.service.AgenteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/agentes")
@RequiredArgsConstructor
public class AgenteController {
    private final AgenteService agenteService;

    @PostMapping
    public ResponseEntity<AgenteAliado> crear(@RequestBody AgenteAliado a){
        return ResponseEntity.status(HttpStatus.CREATED).body(agenteService.registrar(a));
    }

    @PutMapping("/{id}/almacen/{idAlmacen}")
    public ResponseEntity<AgenteAliado> asignarAlmacen(@PathVariable Long id, @PathVariable Long idAlmacen){
        return ResponseEntity.ok(agenteService.asignarAlmacen(id, idAlmacen));
    }
}
