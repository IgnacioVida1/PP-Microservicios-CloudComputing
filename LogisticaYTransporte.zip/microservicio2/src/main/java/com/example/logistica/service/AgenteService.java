package com.example.logistica.service;

import com.example.logistica.entity.AgenteAliado;

public interface AgenteService {
    AgenteAliado registrar(AgenteAliado a);
    AgenteAliado asignarAlmacen(Long idAgente, Long idAlmacen);
}
