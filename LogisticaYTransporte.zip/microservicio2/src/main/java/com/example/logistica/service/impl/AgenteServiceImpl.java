package com.example.logistica.service.impl;

import com.example.logistica.entity.AgenteAliado;
import com.example.logistica.repository.AgenteRepository;
import com.example.logistica.service.AgenteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AgenteServiceImpl implements AgenteService {
    private final AgenteRepository agenteRepository;

    @Override
    public AgenteAliado registrar(AgenteAliado a) {
        return agenteRepository.save(a);
    }

    @Override
    public AgenteAliado asignarAlmacen(Long idAgente, Long idAlmacen) {
        AgenteAliado a = agenteRepository.findById(idAgente).orElseThrow(() -> new RuntimeException("Agente no encontrado"));
        a.setIdAlmacen(idAlmacen);
        return agenteRepository.save(a);
    }
}
