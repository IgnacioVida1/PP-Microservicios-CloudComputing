package com.example.logistica.controller;

import com.example.logistica.entity.Vehiculo;
import com.example.logistica.service.VehiculoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/vehiculos")
@RequiredArgsConstructor
public class VehiculoController {
    private final VehiculoService vehiculoService;

    @PostMapping
    public ResponseEntity<Vehiculo> crear(@RequestBody Vehiculo v){
        return ResponseEntity.status(HttpStatus.CREATED).body(vehiculoService.registrar(v));
    }

    @PutMapping("/{id}/conductor/{idConductor}")
    public ResponseEntity<Void> asignarConductor(@PathVariable Long id, @PathVariable Long idConductor){
        vehiculoService.asignarConductor(id, idConductor);
        return ResponseEntity.noContent().build();
    }
}
