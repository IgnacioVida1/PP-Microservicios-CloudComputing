package com.example.logistica.repository;

import com.example.logistica.entity.ClienteFinal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<ClienteFinal, Long> {}
