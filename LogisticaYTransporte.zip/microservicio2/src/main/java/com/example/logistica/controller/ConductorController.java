package com.example.logistica.controller;

import com.example.logistica.dto.ConductorDTO;
import com.example.logistica.service.ConductorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/conductores")
@RequiredArgsConstructor
public class ConductorController {
    private final ConductorService conductorService;

    @PostMapping
    public ResponseEntity<ConductorDTO> crear(@RequestBody ConductorDTO dto){
        return ResponseEntity.status(HttpStatus.CREATED).body(conductorService.registrar(dto));
    }

    @GetMapping("/disp")
    public ResponseEntity<List<ConductorDTO>> disponibles(){
        return ResponseEntity.ok(conductorService.consultarDisponibilidad());
    }

    @PutMapping("/{id}/vehiculo/{idVehiculo}")
    public ResponseEntity<Void> asignarVehiculo(@PathVariable Long id, @PathVariable Long idVehiculo){
        conductorService.asignarVehiculo(id, idVehiculo);
        return ResponseEntity.noContent().build();
    }
}
