package com.example.logistica.controller;

import com.example.logistica.entity.ClienteFinal;
import com.example.logistica.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/clientes")
@RequiredArgsConstructor
public class ClienteController {
    private final ClienteRepository clienteRepository;

    @PostMapping
    public ResponseEntity<ClienteFinal> crear(@RequestBody ClienteFinal c){
        return ResponseEntity.status(HttpStatus.CREATED).body(clienteRepository.save(c));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteFinal> obtener(@PathVariable Long id){
        return clienteRepository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
}
