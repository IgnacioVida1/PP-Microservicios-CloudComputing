package com.example.logistica.dto;

import lombok.Data;

@Data
public class ConductorDTO {
    private Long idConductor;
    private Long idAgente;
    private Long idVehiculo;
    private String nombre;
    private String dni;
    private String telefono;
    private Boolean disponible;
}
