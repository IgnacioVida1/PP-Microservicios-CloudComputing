-- Optional: sample data (run against the DB)
INSERT INTO agente_aliado(nombre, ruc, telefono) VALUES ('Agencia X','20123456789','999888777');
INSERT INTO vehiculo(nombre,tipo,modelo,color,placa) VALUES ('Camion A','Camion','2020','Blanco','ABC-123');
INSERT INTO conductor(nombre,dni,telefono,disponible) VALUES ('Juan Perez','12345678','987654321', true);
