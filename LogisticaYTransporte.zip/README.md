Microservicio 2 - Logística y Transporte

Estructura:
- doc/: documentación y resumen del PDF del enunciado.
- microservicio2/: código Java Spring Boot listo para compilar y desplegar.

Instrucciones rápidas:
1. Entrar a microservicio2:
   cd microservicio2
2. Compilar:
   mvn clean package -DskipTests
3. Levantar (con Docker):
   docker-compose up --build

Archivo adicional: init_db.sql con datos de ejemplo en microservicio2 root.

Sube esta carpeta al repositorio GitHub del equipo (una sola rama main es suficiente).
