# Proyecto Parcial - Entrega Semana 7

(Contenido extraído del PDF del enunciado)

## Microservicio 2 – Logística y Transporte
Proyecto: Microservicio_Logistica_Transporte (Java Spring Boot + PostgreSQL) Responsable: Persona 2

### Resumen
Este documento contiene todo lo necesario para levantar el microservicio de Logística y Transporte:
esquema SQL, docker-compose , configuración Spring Boot, pom.xml , entidades JPA, repositorios,
servicios, controllers REST, DTOs, ejemplos de uso ( curl ) y consideraciones.

### Entidades principales
- AgenteAliado: registrar agentes, asignar almacén, consultar agente.
- Vehiculo: registrar vehículo, asignar conductor, consultar vehículo.
- Conductor: registrar conductor, asignar vehículo, consultar disponibilidad.
- ClienteFinal: registrar y consultar cliente.

### Estructura propuesta del proyecto
(misma estructura ya incluida en el repositorio generado)

### SQL (PostgreSQL) — esquema inicial
CREATE TABLE agente_aliado (
id_agente BIGSERIAL PRIMARY KEY,
id_almacen BIGINT,
ids_conductor BIGINT[], -- array of conductor ids (optional)
nombre VARCHAR(200) NOT NULL,
ruc VARCHAR(20),
telefono VARCHAR(50),
created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE vehiculo (
id_vehiculo BIGSERIAL PRIMARY KEY,
id_conductor BIGINT,
nombre VARCHAR(200),
tipo VARCHAR(50),
modelo VARCHAR(100),
color VARCHAR(50),
placa VARCHAR(50) UNIQUE,
created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE conductor (
id_conductor BIGSERIAL PRIMARY KEY,
id_agente BIGINT,
id_vehiculo BIGINT,
nombre VARCHAR(200) NOT NULL,
dni VARCHAR(20) UNIQUE,
telefono VARCHAR(50),
disponible BOOLEAN DEFAULT true,
created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE cliente_final (
id_cliente_final BIGSERIAL PRIMARY KEY,
nombre VARCHAR(200) NOT NULL,
correo VARCHAR(200),
telefono VARCHAR(50),
direccion_principal TEXT,
created_at TIMESTAMP DEFAULT now()
);
-- FK (optional)
ALTER TABLE vehiculo
ADD CONSTRAINT fk_vehiculo_conductor FOREIGN KEY (id_conductor) REFERENCES
conductor(id_conductor);
ALTER TABLE conductor
ADD CONSTRAINT fk_conductor_agente FOREIGN KEY (id_agente) REFERENCES
agente_aliado(id_agente);
ALTER TABLE conductor
ADD CONSTRAINT fk_conductor_vehiculo FOREIGN KEY (id_vehiculo) REFERENCES
vehiculo(id_vehiculo);

### docker-compose.yml (Postgres + app)
(El archivo docker-compose.yml ya está en la carpeta del proyecto)

### pom.xml (dependencias clave)
(El archivo pom.xml ya está en la carpeta del proyecto)

### application.yml
(El archivo application.yml ya está en la carpeta del proyecto)

### Código Java clave (resumen)
(Entidades JPA, repositorios, servicios y controllers incluidos en el proyecto)

### Repositorios (ejemplo)
(Se incluyen interfaces JpaRepository en la carpeta repository/)

### Servicios (lógica importante)
(Implementaciones básicas en service/impl/)

### Controllers — endpoints sugeridos
- POST /api/agentes — crear agente
- GET /api/agentes/{id} — obtener agente
- PUT /api/agentes/{id}/almacen/{idAlmacen} — asignar almacén
- POST /api/vehiculos — crear vehículo
- GET /api/vehiculos/{id} — obtener vehículo
- PUT /api/vehiculos/{id}/conductor/{idConductor} — asignar conductor
- POST /api/conductores — crear conductor
- GET /api/conductores/disp — listar disponibles
- PUT /api/conductores/{id}/vehiculo/{idVehiculo} — asignar vehículo
- POST /api/clientes — crear cliente
- GET /api/clientes/{id} — obtener cliente

### Ejemplos curl
Crear conductor:
curl -X POST http://localhost:8080/api/conductores -H 'Content-Type: application/json' -d '{"nombre":"Juan Perez","dni":"12345678","telefono":"987654321"}'
Listar conductores disponibles:
curl http://localhost:8080/api/conductores/disp
Asignar conductor a vehículo:
curl -X PUT http://localhost:8080/api/vehiculos/5/conductor/2
Registrar agente aliado:
curl -X POST http://localhost:8080/api/agentes -H 'Content-Type: application/json' -d '{"nombre":"Agencia X","ruc":"20123456789","telefono":"999888777" }'

### Buenas prácticas y extensiones sugeridas
- Añadir autenticación/autorization (JWT).
- Añadir tests unitarios e integracion (Testcontainers).
- Versionar API /api/v1/...
- Monitorización (Actuator + Prometheus).
- Eventos asíncronos (Kafka/RabbitMQ).

### ¿Qué entrego en el repo?
- SQL para crear tablas (schema + init_db.sql)
- docker-compose para levantar Postgres y la app
- application.yml listo para variables de entorno
- pom.xml con dependencias
- Código Java para entidades, repos, servicios y controllers (esqueleto listo para copiar y completar)
- curl samples

